# Campeões do Futuro - Site

Site oficial do projeto Campeões do Futuro, academia de Jiu-Jitsu.

## 🥋 Sobre o Projeto

Fundado em 2018 por Gesilvânio Lima (Cigano), o projeto Campeões do Futuro tem como missão transformar vidas através do Jiu-Jitsu. Com academias localizadas nos bairros Nova Vitória e Gleba E, oferecemos treinamento de alto nível para atletas iniciantes e avançados.

## 🚀 Tecnologias Utilizadas

- React 18
- Vite
- Tailwind CSS
- Shadcn/ui

## 📱 Funcionalidades

- Design responsivo
- Navegação suave entre seções
- Interface moderna e atrativa
- Otimizado para performance

## 🌐 Deploy

Este site está configurado para ser hospedado no GitHub Pages.

### Como fazer deploy:

1. Faça o build do projeto:
```bash
npm run build
```

2. Os arquivos de produção estarão na pasta `dist/`

3. Configure o GitHub Pages para usar a pasta `dist/` ou faça o deploy manual dos arquivos

## 📞 Contato

- **Instagram:** [@campeoes_fight](https://instagram.com/campeoes_fight)

---

© 2025 Campeões do Futuro - Todos os direitos reservados

