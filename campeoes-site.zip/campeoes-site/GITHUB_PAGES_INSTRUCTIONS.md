# Instruções para Hospedagem no GitHub Pages

## Passo a Passo para Hospedar o Site

### 1. Criar Repositório no GitHub
1. Acesse [GitHub.com](https://github.com)
2. Clique em "New repository"
3. Nomeie o repositório (ex: `campeoes-do-futuro-site`)
4. Marque como público
5. Clique em "Create repository"

### 2. Fazer Upload dos Arquivos

#### Opção A: Via Interface Web do GitHub
1. No repositório criado, clique em "uploading an existing file"
2. Arraste todos os arquivos da pasta `/home/ubuntu/campeoes-site/`
3. Faça commit das mudanças

#### Opção B: Via Git (se você tem Git instalado)
```bash
git remote add origin https://github.com/SEU_USUARIO/NOME_DO_REPOSITORIO.git
git branch -M main
git push -u origin main
```

### 3. Configurar GitHub Pages
1. No repositório, vá em "Settings"
2. Role até a seção "Pages"
3. Em "Source", selecione "Deploy from a branch"
4. Selecione a branch "main" ou "master"
5. Selecione a pasta "/ (root)"
6. Clique em "Save"

### 4. Configurar para Build Automático
Para que o GitHub Pages faça o build automaticamente do React:

1. Crie um arquivo `.github/workflows/deploy.yml` com o seguinte conteúdo:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout
      uses: actions/checkout@v3
      
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        
    - name: Install dependencies
      run: npm install
      
    - name: Build
      run: npm run build
      
    - name: Deploy
      uses: peaceiris/actions-gh-pages@v3
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./dist
```

### 5. Acessar o Site
Após alguns minutos, seu site estará disponível em:
`https://SEU_USUARIO.github.io/NOME_DO_REPOSITORIO/`

## Arquivos Importantes

- **dist/**: Pasta com os arquivos de produção (build)
- **src/**: Código fonte do React
- **README.md**: Documentação do projeto
- **.gitignore**: Arquivos que o Git deve ignorar
- **package.json**: Dependências e scripts do projeto

## Atualizações Futuras

Para atualizar o site:
1. Modifique os arquivos necessários
2. Faça commit das mudanças
3. Faça push para o GitHub
4. O GitHub Actions fará o deploy automaticamente (se configurado)

## Suporte

Se precisar de ajuda, consulte a [documentação oficial do GitHub Pages](https://docs.github.com/en/pages).

